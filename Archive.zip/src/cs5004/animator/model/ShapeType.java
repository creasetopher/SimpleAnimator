package cs5004.animator.model;

/**
 * This is an enum representing all possible shape types.
 */
public enum ShapeType {

  RECTANGLE, ELIPSE, TRIANGLE

}
